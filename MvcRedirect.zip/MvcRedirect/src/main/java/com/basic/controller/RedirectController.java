package com.basic.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class RedirectController {
	
	@RequestMapping("/one")
	/*public String one()
	{
		System.out.println("this is first handler");
		return "redirect:/enjoy";
	}*/
	public RedirectView one()
	{
		System.out.println("this is first handler");
		RedirectView redirectView = new RedirectView();
         redirectView.setUrl("enjoy");
		//redirectView.setUrl("https://www.google.com");
		return redirectView;
	}
	
	
	@RequestMapping("/enjoy")
	public String two()
	{
		System.out.println("this is Second handler[Enjoy]");
		return "Hi";
	}
}
